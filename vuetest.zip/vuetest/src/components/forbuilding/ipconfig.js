const host = 'http://39.104.22.54:8082/';
// const host = 'http://localhost:8082/';
// http://39.104.22.54:8082/images/d1f1a628-8f7d-4763-b853-80d62f03b6a8.jpg
export default{
    host,    //地址
}
